const INITIAL_STATE = {
  loading: false,
  message: null,
  currentRoute: "/",
};

export default INITIAL_STATE;
