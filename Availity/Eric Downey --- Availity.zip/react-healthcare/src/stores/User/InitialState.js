const INITIAL_STATE = {
  firstName: "",
  lastName: "",
  npiNumber: "",
  businessAddress: "",
  telephoneNumber: "",
  emailAddress: "",
};

export default INITIAL_STATE;
