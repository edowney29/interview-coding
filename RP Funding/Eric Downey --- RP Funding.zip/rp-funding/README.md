## RP Funding Express, React, MySQL assignment

 To run this project, update the Config folder with your local MySQL database config (i.e. username and password)

 Next, run `npm install` then `npm start` and head to http://localhost:8080/

 Formatted with Prettier
